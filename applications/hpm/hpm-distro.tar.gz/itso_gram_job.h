#ifndef ITSO_GRAM_JOB_H
#define ITSO_GRAM_JOB_H
#include <cstdio> 
#include <string>
#include "globus_gram_client.h"
#include "itso_cb.h"
using namespace std;

class ITSO_GRAM_JOB : public ITSO_CB {
	ITSO_CB request_cb;  	// callback used for 
				// globus_gram_client_register_job_request
	char* 	job_contact;
        char* 	callback_contact; /* This is the identifier for
                                   * the callback, returned by
                                   * globus_gram_job_request

				   */
	bool   failed;		// used to check if a job has failed
     public:
	ITSO_GRAM_JOB();
	~ITSO_GRAM_JOB();
	bool Submit(string, string);
	void Cancel();
	void SetRequestDone(const char*);
	void Wait();
	void SetFailed();
	bool HasFailed();
};


#endif
