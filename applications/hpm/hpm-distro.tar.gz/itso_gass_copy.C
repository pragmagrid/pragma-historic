/**********************************************
 *  For a mote complete example 
 *  see globus-url-copy.c
 **********************************************/
#include "itso_gass_copy.h"


GLOBUS_FILE::GLOBUS_FILE() {};
GLOBUS_FILE::GLOBUS_FILE(char* filename) {
	io_handle =(globus_io_handle_t *) globus_libc_malloc(sizeof(globus_io_handle_t));
	file_fd=open(filename,O_RDONLY);
       	/* convert file  into a globus_io_handle */
       	globus_io_file_posix_convert(file_fd,
                                    GLOBUS_NULL,
                                   io_handle);
};

GLOBUS_FILE::~GLOBUS_FILE(){
	close(file_fd);
	globus_libc_free(io_handle);
};
	
globus_io_handle_t * GLOBUS_FILE::get_globus_io_handle() {
	return io_handle;
};



GLOBUS_URL::GLOBUS_URL() {};
GLOBUS_URL::~GLOBUS_URL() {
	free(URL);
};
bool GLOBUS_URL::setURL(char* destURL) {
    	//check if this is a valid URL	
	if (globus_url_parse(destURL, &url) != GLOBUS_SUCCESS) {
             cerr << "can not parse destURL" << destURL << endl;
	     return false;
	}
	//determine the transfer mode
	if (globus_gass_copy_get_url_mode(destURL, &url_mode) != GLOBUS_SUCCESS) {
 	     cerr << "failed to determine mode fmeor destURL" << destURL << endl;
	     return false;
	};
	URL=strdup(destURL);
	return true;
};

bool GLOBUS_URL::setURL(string url) {
	return setURL(const_cast<char*>(url.c_str()));
}

globus_gass_copy_url_mode_t GLOBUS_URL::getMode() {
	return url_mode;
};

char* GLOBUS_URL::getScheme() {
	return url.scheme;
}

char* GLOBUS_URL::getURL() {
	return URL;
}


//***********************************************************
//
//
//***********************************************************
namespace itso_gass_copy {
static void
url_copy_callback(
		    void * callback_arg,
		    globus_gass_copy_handle_t * handle,
		    globus_object_t * error)
{
            globus_bool_t         use_err = GLOBUS_FALSE;
	    ITSO_CB* monitor = (ITSO_CB*)  callback_arg;

            if (error != GLOBUS_SUCCESS)
	    {
		      cerr << " url copy error:" <<   globus_object_printable_to_string(error) << endl;
		      //monitor->setError(error);
      	    }
	    monitor->setDone();
        return;
};
}

ITSO_GASS_TRANSFER::ITSO_GASS_TRANSFER() {
	// handlers initialisation
	// first the attributes
	// then the handler
	globus_gass_copy_handleattr_init(&gass_copy_handleattr);
	globus_gass_copy_handle_init(&gass_copy_handle, &gass_copy_handleattr);	
};


ITSO_GASS_TRANSFER::~ITSO_GASS_TRANSFER() {
	globus_gass_copy_handle_destroy(&gass_copy_handle);	
	if (source_url_mode == GLOBUS_GASS_COPY_URL_MODE_FTP)
		globus_libc_free(source_ftp_attr);
	if (dest_url_mode == GLOBUS_GASS_COPY_URL_MODE_FTP)
		globus_libc_free(dest_ftp_attr);
	if (source_url_mode == GLOBUS_GASS_COPY_URL_MODE_GASS)
		globus_libc_free(source_gass_attr);
	if (dest_url_mode == GLOBUS_GASS_COPY_URL_MODE_GASS)
		globus_libc_free(dest_gass_attr);
}


void ITSO_GASS_TRANSFER::setSource(GLOBUS_URL& source_url) {
				
	globus_gass_copy_attr_init(&source_gass_copy_attr);
	source_url_mode=source_url.getMode();
	if (source_url_mode == GLOBUS_GASS_COPY_URL_MODE_FTP) {
		source_ftp_attr = (globus_ftp_client_operationattr_t*) globus_libc_malloc (sizeof(globus_ftp_client_operationattr_t));
		
		globus_ftp_client_operationattr_init(source_ftp_attr);
		globus_gass_copy_attr_set_ftp(&source_gass_copy_attr,
						source_ftp_attr);
	}
	else if (source_url_mode == GLOBUS_GASS_COPY_URL_MODE_GASS) {
		source_gass_attr = (globus_gass_transfer_requestattr_t*) globus_libc_malloc (sizeof(globus_gass_transfer_requestattr_t));
       		globus_gass_transfer_requestattr_init(source_gass_attr,source_url.getScheme());
   		globus_gass_copy_attr_set_gass(&source_gass_copy_attr, source_gass_attr);
		globus_gass_transfer_requestattr_set_file_mode(
	          source_gass_attr,
	          GLOBUS_GASS_TRANSFER_FILE_MODE_BINARY);
		globus_gass_copy_attr_set_gass(&source_gass_copy_attr,
				                    source_gass_attr);
	};
};

	
void ITSO_GASS_TRANSFER::setDestination(GLOBUS_URL& dest_url) {
	globus_gass_copy_attr_init(&dest_gass_copy_attr);
	dest_url_mode=dest_url.getMode();
	if (dest_url_mode == GLOBUS_GASS_COPY_URL_MODE_FTP) {
		dest_ftp_attr = (globus_ftp_client_operationattr_t*)globus_libc_malloc (sizeof(globus_ftp_client_operationattr_t));
		globus_ftp_client_operationattr_init(dest_ftp_attr);
		globus_gass_copy_attr_set_ftp(&dest_gass_copy_attr,
						dest_ftp_attr);
	}
	else if (dest_url_mode == GLOBUS_GASS_COPY_URL_MODE_GASS) {
		dest_gass_attr = (globus_gass_transfer_requestattr_t*)globus_libc_malloc (sizeof(globus_gass_transfer_requestattr_t));
       		globus_gass_transfer_requestattr_init(dest_gass_attr, dest_url.getScheme());
   		globus_gass_copy_attr_set_gass(&dest_gass_copy_attr, dest_gass_attr);
		globus_gass_transfer_requestattr_set_file_mode(
	          dest_gass_attr,
	          GLOBUS_GASS_TRANSFER_FILE_MODE_BINARY);
		globus_gass_copy_attr_set_gass(&dest_gass_copy_attr,
				                    dest_gass_attr);
	};
};

void ITSO_GASS_TRANSFER::Transfer(GLOBUS_FILE& globus_source_file, GLOBUS_URL& destURL) {
		setDestination(destURL);
globus_result_t result = globus_gass_copy_register_handle_to_url(
			&gass_copy_handle,
                      	globus_source_file.get_globus_io_handle(),
              	 	destURL.getURL(),
              		&dest_gass_copy_attr,
			itso_gass_copy::url_copy_callback,
               	      	(void *) this );
};

void ITSO_GASS_TRANSFER::Transfer(GLOBUS_URL& sourceURL,GLOBUS_FILE& globus_dest_file) {
		setSource(sourceURL);
globus_result_t result = globus_gass_copy_register_url_to_handle(
			&gass_copy_handle,
			sourceURL.getURL(),
              		&source_gass_copy_attr,
                      	globus_dest_file.get_globus_io_handle(),
			itso_gass_copy::url_copy_callback,
               	      	(void *) this );
};

void ITSO_GASS_TRANSFER::Transfer(GLOBUS_URL& sourceURL,GLOBUS_URL& destURL) {
		setSource(destURL);
		setDestination(destURL);
globus_result_t result = globus_gass_copy_register_url_to_url(
                    	&gass_copy_handle,
                       	sourceURL.getURL(),
               		&source_gass_copy_attr,
                       	destURL.getURL(),
                       	&dest_gass_copy_attr,
			itso_gass_copy::url_copy_callback,
                       	(void *) this);
};

