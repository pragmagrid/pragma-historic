#include "itso_gram_job.h"

//using namespace std;
namespace itso_gram_job {
static void callback_func(void * user_callback_arg,
                   char * job_contact,
                   int state,
                   int errorcode)
{
//    printf("entered callback func\n");
    ITSO_GRAM_JOB*  Monitor = (ITSO_GRAM_JOB*) user_callback_arg;

    switch(state)
    {
    case GLOBUS_GRAM_PROTOCOL_JOB_STATE_STAGE_IN:
	std::cout << "Staging file in on: " << job_contact << std::endl;
	break;
    case GLOBUS_GRAM_PROTOCOL_JOB_STATE_STAGE_OUT:
	std::cout << "Staging file out  on: " << job_contact << std::endl;
	break;
    case GLOBUS_GRAM_PROTOCOL_JOB_STATE_PENDING:
	break; /* Reports state change to the user */

    case GLOBUS_GRAM_PROTOCOL_JOB_STATE_ACTIVE:
	break; /* Reports state change to the user */
   
    case GLOBUS_GRAM_PROTOCOL_JOB_STATE_FAILED:
	std::cerr << "Job Failed on: " << job_contact << std::endl;
	Monitor->SetFailed();
        Monitor->setDone();
	break; /* Reports state change to the user */

    case GLOBUS_GRAM_PROTOCOL_JOB_STATE_DONE:
	std::cout << "Job Finished on: " << job_contact << std::endl;
        Monitor->setDone();
	break; /* Reports state change to the user */
    }
}

static void request_callback(void * user_callback_arg,
                             globus_gram_protocol_error_t failure_code,
                             const char * job_contact,
                             globus_gram_protocol_job_state_t state,
                             globus_gram_protocol_error_t errorcode) {
    ITSO_GRAM_JOB*  Request = (ITSO_GRAM_JOB*) user_callback_arg;
    cout << "Contact on the server " << job_contact << endl;
    Request->SetRequestDone(job_contact);
}
}

ITSO_GRAM_JOB::ITSO_GRAM_JOB() {
};

ITSO_GRAM_JOB::~ITSO_GRAM_JOB() {
};

void ITSO_GRAM_JOB::SetRequestDone( const char* j) {
	job_contact = const_cast<char*>(j);
	cout<<"job contact: "<<job_contact<<endl;
	request_cb.setDone();
}


	
bool ITSO_GRAM_JOB::Submit(std::string res, std::string rsl) {
    failed=false;
    printf("entered submit routine\n");
    globus_gram_client_callback_allow(itso_gram_job::callback_func, (void *) this, &callback_contact);
    cout<<"callback_contact="<<callback_contact<<endl;
    int rc = globus_gram_client_register_job_request(res.c_str(),
                         rsl.c_str(),
	                 GLOBUS_GRAM_PROTOCOL_JOB_STATE_ALL,
		         callback_contact,
                         GLOBUS_GRAM_CLIENT_NO_ATTR,
			 itso_gram_job::request_callback,
			 (void*) this);
    if (rc != 0) /* if there is an error */
    {
        printf("TEST: gram error: %d - %s\n", 
                rc, 
                /* translate the error into english */
                globus_gram_client_error_string(rc));
        return true;
    }
    else
	return false;
    printf("submitted\n");
};


void ITSO_GRAM_JOB::Wait() {
	request_cb.Wait();
	ITSO_CB::Wait();
        /* Free up the resources of the job_contact, as the job is over, and
         * the contact is now useless.
         */
        globus_gram_client_job_contact_free(job_contact);
	request_cb.Continue();
	ITSO_CB::Continue();
};


void ITSO_GRAM_JOB::Cancel() {
    int rc;
    printf("\tTEST: sending cancel to job manager...\n");

    if ((rc = globus_gram_client_job_cancel(job_contact)) != 0)
    {
       printf("\tTEST: Failed to cancel job.\n");
       printf("\tTEST: gram error: %d - %s\n", 
               rc,
               globus_gram_client_error_string(rc));
    }
    else
    {
       printf("\tTEST: job cancel was successful.\n");
    }
};

void ITSO_GRAM_JOB::SetFailed() {
	failed=true;
}


bool ITSO_GRAM_JOB::HasFailed() {
	return failed;
}

