// Ap dung Thuat toan gom nhom DBSCAN
#include <complex>
class ClusterAlgorithm{

      int numHapControl;
      int numHapCase;
      int** matrix_Haplotype;
      ParameterDataHPM paraHPM;
      ParameterData paraData;
      int rowHapClusterAll;
	  
 public:
    ClusterAlgorithm(int** hap, ParameterData& pa, ParameterDataHPM& pHPM, int nCase, int nCon){
				matrix_Haplotype = hap;
				paraData = pa;
				paraHPM = pHPM;
				numHapControl = nCon;
				numHapCase = nCase;
				rowHapClusterAll = 0;
	}
    int getRowHapClusterAll(){
        return  rowHapClusterAll;
    }
//-------------------------------------------------------------------------------------
	int iFunction(int hik, int hjk){
			if (hik == hjk) return 1;
			else return 0;
	}
//-------------------------------------------------------------------------------------
// ham similarity
	double sim_m1(int hi, int hj){
		// tinh tong aaa
		int* vecSim = vectorSim(hi, hj);
		double sumA = 0;
		int marker = paraData.getTotalMarker();
		int alpha = paraData.getAlpha();
		int start= 2 - paraData.getLenHapSegment(); // so am

		
		int k;
		for (k=start; k< marker; k++)
			sumA = sumA + pow(aaa_m1(k, vecSim),alpha);
		double cc = 0;
		for (k=1; k<paraData.getLenHapSegment(); k++)
			cc = cc + pow((double)k, alpha);
		//tinh maximun score
		double scoreC = (marker - paraData.getLenHapSegment() +1)*pow((double)paraData.getLenHapSegment(), alpha) + 2*cc;

		freeMemVector(vecSim);

		return sumA/scoreC;
		
	}
//-------------------------------------------------------------------------------------
	int* vectorSim(int hi, int hj){

		int marker = paraData.getTotalMarker();
		int* result = getMemVector(marker);
		for (int k=0; k<paraData.getTotalMarker(); k++)
			result[k] = iFunction(matrix_Haplotype[hi-1][k+4], matrix_Haplotype[hj-1][k+4]); //4: do chua 4 cot ID, Status, ClID, Core?
		return result;
	}
//-------------------------------------------------------------------------------------				
	double aaa_m1(int markerK, int* vecSim){
		int len = paraData.getLenHapSegment();
		double result=0;
		for (int k=markerK; k<(markerK+len); k++){
			if ((k>=0) && (k<paraData.getTotalMarker()))
			    result = result + vecSim[k];
			else 
				result = result + 0;
		}
		return result;
	}
   
//-------------------------------------------------------------------------------------				
	double aaa_m2(int* vecSim){
		int len = paraData.getLenHapSegment();
		double result=0;
		// tim cac doan trung lap
		int start = 0; // vi tri bat dau
		int value = 1; // neu co' match giua hi, hj
		int found = 0;
		for (int k=0; k<paraData.getTotalMarker(); k++)
			if ((vecSim[k] == value) && (found == 0)){
				start = k;
				found = 1;
			}
			else
				if ((vecSim[k] != value) && (found == 1)){
					found = 0;
					if (k-start>1)  // do dai lon hon 1
						result = result + pow((double)(k - start), paraData.getAlpha());
				}

		return result;
	}
//-------------------------------------------------------------------------------------				
	//Xay dung ham khoang cach theo phuong phap 1: sliding window
	//Xay dung ham khoang cach theo phuong phap 2: tinh tung doan chuoi con giong nhau
    double distanceTwoHap(int hi, int hj, int disType){			
			// tinh vectorSim
		
		if (disType == 1){
			return 1-sim_m1(hi, hj);
		}
		else
			if (disType == 2){
				int* vecSim = vectorSim(hi, hj);		
				double sim = aaa_m2(vecSim)/pow((double)paraData.getTotalMarker(), paraData.getAlpha());
				freeMemVector(vecSim);
				return 1-sim;
			}
			else
				return 1000; // bi sai du lieu
	}

//-------------------------------------------------------------------------------------
      double z_score(double m_cluster, double n_cluster){
				double n_control=numHapControl;
				double n_case = numHapCase;

				double ts = (m_cluster/(double)n_control) - (n_cluster/n_case);
				double ms = sqrt(((m_cluster + n_cluster)/(n_control+n_case))*(1-((m_cluster+n_cluster)/(n_control+n_case)))*(1/n_case + 1/n_control));
				//std::cout <<"TS:="<<ts<<"--- MS:="<<ms<<"\n" ;
				return ts/ms;
		}
//-------------------------------------------------------------------------------------		
	// thuat toan cluster - DBSCAN - cho tung Marker rieng le
	// file1: Ten file luu bat dau
	// tra ve so cluter tim duoc
	int clusteringAlgorithm(char* file1, char* filePara){
	 	int countClusterID = 1;
		int numResult = 0; int vec_numtemp = 20;
		int* vecIDCluster = getMemVector(vec_numtemp);
		int totalRow = numHapControl + numHapCase;
		double eps = paraData.getEps();
		int minpts = paraData.getMinPts();
		int j;
		   try{
				// duyet tim cac haplotype
				for ( j=0; j<totalRow; j++){
					 int idHapCore = matrix_Haplotype[j][0]; // lay ID
					 if (matrix_Haplotype[j][2] == 0){ //unclassified
					//	std::cout <<"Cluster " << countClusterID<<"   ::  \n";
						if (expandCluster(idHapCore, countClusterID, eps, minpts)==1)
										countClusterID ++;
					 }
				}// for j
				
					
				// xet duyet xem cluster tim duoc trong sliding i co' ket hop manh voi benh khong?								
				for (j=1; j<countClusterID; j++){
						double case_cluster = 0, control_cluster = 0;
						int nRow = paraData.getTotalRow();
						int* idHapCluster = getMemVector(nRow);
                        int numTotalInCluster = 0;
                        //duyet qua matrix_Haplotype de loc cac cluster
						for (int jj=0; jj<totalRow; jj++){
							if (matrix_Haplotype[jj][2] == j){
								if (matrix_Haplotype[jj][1] == 1)
									case_cluster ++;
								else
									control_cluster ++;
								idHapCluster[numTotalInCluster] = matrix_Haplotype[jj][0];
                                numTotalInCluster++;
								}	
						}	
						// tinh Z-Score
						double z_scorei = z_score(case_cluster, control_cluster);
                        std::cout <<"case: "<<case_cluster<<"; control:"<<control_cluster<<"; z-score cua :"<<j<<" = "<< z_scorei<<"\n";
						if (z_scorei > paraData.getZScoreDefault()){
								// dem cluster do
							vecIDCluster[numResult] = j;
							numResult++;
								char tmp[5];
								char fileout[40];
								strcpy(fileout,file1);
								//itoa(j,tmp,10);
								snprintf(tmp,10,"%d",numResult);
								strcat(fileout,tmp);
								strcat(fileout,".txt");
								// luu xuong hai file ket qua: File chua Z-Score cho tung marker, file chua chi tiet cluster									
								std::ofstream fileOut(fileout);
								fileOut << "ID \t"<<"Status \t";
								int jj;
								for (jj=0; jj<paraData.getTotalMarker(); jj++)
									fileOut <<"M"<<(jj+1)<<"\t";

							 	fileOut <<"\n";
								for (jj=0; jj<numTotalInCluster; jj++){
							 			fileOut <<matrix_Haplotype[idHapCluster[jj]-1][0]<<"\t";
										if (matrix_Haplotype[idHapCluster[jj]-1][1] == 1)
											fileOut<< "a"<<"\t";
										else
											fileOut<< "c"<<"\t";
										for (int jjj=4; jjj<paraData.getTotalMarker()+4; jjj++)
												fileOut << matrix_Haplotype[idHapCluster[jj]-1][jjj]<<"\t";
										fileOut <<"\n";
								}
								fileOut.close();

								// ghi file tham so HPM cho cluster nay
								strcpy(fileout,filePara);
								strcat(fileout,tmp);
								strcat(fileout,".txt");
								std::ofstream fileOutPara(fileout);
								fileOutPara << "x\t"<<paraHPM.getThreshold()<<"\n";
								fileOutPara << "length\t"<<paraHPM.getMaxLength()<<"\n";
								fileOutPara << "numgap\t"<< paraHPM.getMaxNumGap()<<"\n";
								fileOutPara << "sizegap\t"<< paraHPM.getMaxSizeGap()<<"\n";
								fileOutPara << "per\t"<< paraHPM.getPermutationTimes()<<"\n";
								fileOutPara << "total\t"<<numTotalInCluster<<"\n";
								fileOutPara << "marker\t"<< paraHPM.getTotalMarker()<<"\n";
								fileOutPara.close();
								
						}

                        // giai phong vung nho*
                        freeMemVector(idHapCluster);
				}// end for j
					
			outPutMatrixHaplotypeCluster("clustered_data_result.txt", vecIDCluster, numResult, rowHapClusterAll);
			freeMemVector(vecIDCluster);
			}catch(char *str){
					std::cout<<"Cannot create output-result file"<<str;
			}

			return numResult;
		}
//-------------------------------------------------------------------------------------		
	int expandCluster(int idHapCore, int currentClusterID, double eps, int minpts){
				// chon loc tat ca cac Haplotype lan can voi hapCore
               // int start = 4;
               // int end = paraData.getTotalMarker(); //paraData.getLenHapSegment()+ start;
                int numRecord = 0;
			//	std::cout <<"Ham expandCluster\n";
				int* listHap = getListHaplotype(idHapCore, eps, numRecord );
				if (numRecord < minpts){ // no core point
						matrix_Haplotype[idHapCore-1][2]= -1;
						return 0;
				}
				else{// core point
						// tat ca ca Hap trong listHap deu dat den tu hapCore
						for (int i=0; i<numRecord; i++){
						    matrix_Haplotype[listHap[i]-1][2] = currentClusterID;
                            matrix_Haplotype[listHap[i]-1][3] = 1;  // xac dinh core hap
                        }
						//xoa hapCore trong listHap
						removeElement(listHap, idHapCore, numRecord);
						// tim tiep cac haplotype khac voi haplotype lo~i ban dau
						while (numRecord>0){
                            int numTemp = 0;
							int currentP = matrix_Haplotype[listHap[0]-1][0];
        					int* listHap_result = getListHaplotype(currentP, eps, numTemp);
							if (numTemp >= minpts){
								for (int ii=0; ii<numTemp; ii++){
									int idResultP = listHap_result[ii];
									if ((matrix_Haplotype[idResultP-1][2] == 0) || (matrix_Haplotype[idResultP-1][2] == -1)){ // unclassified or noise
										if (matrix_Haplotype[idResultP-1][2] == 0)
											addElement(listHap, idResultP, numRecord);
         								matrix_Haplotype[idResultP-1][2]= currentClusterID;
                                        matrix_Haplotype[idResultP-1][3]= 1;
									}
								}
							}
								removeElement(listHap, currentP, numRecord);
						}// end while
				}
              return 1;
		}
//-------------------------------------------------------------------------------------		
//loc lay danh sach tat ca cac Haplotype thoa Eps-Neighborhood, dinh nghia 1
// output: Vector chua cac ID cua Haplotype thoa dieu kien
// khong co' ID cludter truoc
		int* getListHaplotype(int hapCore, double eps, int& numRecord){
				
				int totalRow = paraData.getTotalRow();
				int* result = getMemVector(totalRow);
				//su dung hai ham distanceTwoHap & similarityScore
			//	std::cout << "Ham getList "<<totalRow<<"\n";
				for (int jj=0; jj<totalRow; jj++){
					int hapTemp = matrix_Haplotype[jj][0];
				//	std::cout << " lay ID phan tu thu"<<jj<<"="<<matrix_Haplotype[jj][0]<<"\n";
					if (matrix_Haplotype[jj][2]<1)
						if (distanceTwoHap(hapCore, hapTemp, paraData.getDisType()) <= eps)
								addElement(result,hapTemp, numRecord);
						
				}
				return result;
		}
//-------------------------------------------------------------------------------------		
// remove mot phan tu trong mang mot chieu
void removeElement(int* list, int value, int& numRecord){
    int found = 0;
    int i = 0;
    while ((found == 0) && (i<numRecord))
          if (list[i] == value)
               found = 1;
          else
             i++;
    // xoa phan tu
    if (found == 1){
        for (int j=i; j< numRecord; j++)
            list[j] = list[j+1];
        numRecord --;
    }
}
//-------------------------------------------------------------------------------------		
// them mot phan tu trong mang mot chieu
void addElement(int* list, int value, int& numRecord){
       list[numRecord] = value;
       numRecord ++;
}
//---------------------------------------------------------------------------------------
// the end of file
void outPutMatrixHaplotypeCluster (char * filename, int* vecIDCluster, int numResult, int& rowHapClusterAll){
     // xuat gia tri cua matrix
	 
     int row1 = paraData.getTotalRow();
     int col1 = paraData.getTotalMarker()+4;

    //Xuat ra file
    std::cout <<"bat dau dem "<<rowHapClusterAll<<std::endl;		
    std::ofstream examplefile1 (filename);
    if (examplefile1.is_open())
    { int i=0, j=0, ii=0;
     examplefile1 <<"ID"<<"\t"<<"Status"<<"\t";
     for (i=0; i<col1-4; i++){
 	examplefile1 <<"M"<<(i+1)<<"\t";
     }
     examplefile1 <<"\n";
    for (ii=0; ii<numResult; ii++){
     for (i=0; i<row1; i++){
         if (matrix_Haplotype[i][2]==vecIDCluster[ii]){
            rowHapClusterAll++;
            examplefile1 << matrix_Haplotype[i][0]<<"\t";
            if (matrix_Haplotype[i][1]==1)
                examplefile1 <<"a"<<"\t";
            else
                examplefile1 <<"c"<<"\t";
            for (j=4; j<col1; j++)
                examplefile1 << matrix_Haplotype[i][j]<<"\t";
            examplefile1 << "\n";
          }
      }
    }
      examplefile1.close();
    }
   
   std::cout<<"Cluser row search: "<<rowHapClusterAll<<std::endl;
}
//--------------------------------------------------------------------------------------------
};
