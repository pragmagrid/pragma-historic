#include "itso_globus_ftp_client.h"

namespace itso_globus_ftp_client {
static void done_cb(void* user_arg,globus_ftp_client_handle_t* handle,globus_object_t* err)
{
    ITSO_CB* f=(ITSO_CB*) user_arg;

    if(err)
    {
        cerr << globus_object_printable_to_string(err);
    };
    f->setDone();
    return;
};

static
void
data_cb(
    void *                                      user_arg,
    globus_ftp_client_handle_t *                handle,
    globus_object_t *                           err,
    globus_byte_t *                             buffer,
    globus_size_t                               length,
    globus_off_t                                offset,
    globus_bool_t                               eof)
{
    ITSO_GLOBUS_FTP_CLIENT* l = (ITSO_GLOBUS_FTP_CLIENT*) user_arg;

    if(err)
    {
        fprintf(stderr, "%s", globus_object_printable_to_string(err));
    }
    else
    {
        if(!eof)
		l->Transfer(
                                buffer,
                                length,
                                offset
		);
    } /* else */
    return;
} /* data_cb */
};


ITSO_GLOBUS_FTP_CLIENT::ITSO_GLOBUS_FTP_CLIENT(char* f,char* dst) {
		fd = fopen(f,"r");
    		globus_ftp_client_handle_init(&handle,  GLOBUS_NULL);
		globus_result_t r;
    		globus_ftp_client_put(&handle,
                                   dst,
                                   GLOBUS_NULL,
                                   GLOBUS_NULL,
				   itso_globus_ftp_client::done_cb,
                                   this);
	};
ITSO_GLOBUS_FTP_CLIENT::~ITSO_GLOBUS_FTP_CLIENT() {
		fclose(fd);
    		globus_ftp_client_handle_destroy(&handle);
	};
void ITSO_GLOBUS_FTP_CLIENT::StartTransfer() {
        	int rc;
	        rc = fread(buffer, 1, MAX_BUFFER_SIZE, fd);
	        globus_ftp_client_register_write(
        	    &handle,
	            buffer,
        	    rc,
	            0,
        	    feof(fd) != SUCCESS,       
		    itso_globus_ftp_client::data_cb,
	            (void*) this);
	};


void ITSO_GLOBUS_FTP_CLIENT::Transfer(
	    globus_byte_t*                             buffer,
	    globus_size_t&                               length,
	    globus_off_t&                                offset
		     )
{
	int rc;
        rc = fread(buffer, 1, MAX_BUFFER_SIZE, fd);
        if (ferror(fd) != SUCCESS)
        {
            printf("Read error in function data_cb; errno = %d\n", errno);
            return;
        } 
        globus_ftp_client_register_write(
           &handle,
           buffer,
           rc,
           offset + length,
           feof(fd) != SUCCESS,
	   itso_globus_ftp_client::data_cb,
           (void *) this);
};


