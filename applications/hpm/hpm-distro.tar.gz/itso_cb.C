#include "itso_cb.h"

globus_bool_t ITSO_CB::IsDone() { return done; };

void ITSO_CB::setDone() {
              globus_mutex_lock(&mutex);
              done = GLOBUS_TRUE; 
	      globus_cond_signal(&cond);
	      globus_mutex_unlock(&mutex);
            }

void ITSO_CB::Continue() {
              globus_mutex_lock(&mutex);
              done = GLOBUS_FALSE; 
	      globus_mutex_unlock(&mutex);
            }

void ITSO_CB::Wait() {
	globus_mutex_lock(&mutex);
    	while(!IsDone())
        	globus_cond_wait(&cond, &mutex);
	globus_mutex_unlock(&mutex);
};

void ITSO_CB::Lock() { globus_mutex_lock(&mutex); };

void ITSO_CB::UnLock() { globus_mutex_unlock(&mutex); };

