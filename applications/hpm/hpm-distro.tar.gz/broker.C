/* gris_search.c  */
#include "globus_common.h"
#include "globus_gram_client.h"
/* LDAP stuff */
#include "lber.h"
#include "ldap.h"
#include <string>
#include <vector>
#include <algorithm>


/* note this should be the GIIS server, but it could be the 
   GRIS server if you are only talking to a local machine 
   remember the port numbers are different */ 

#define GRID_INFO_HOST "172.25.97.34"
#define GRID_INFO_PORT "2135"
#define GRID_INFO_BASEDN "mds-vo-name=IOIT-HCM, o=Grid"


//*******************************************************************
// This is a basic implementation of a broker.  It checks all available 
// Linux nodes and teir CPU usage.  Use GetLinuxNodes().  The first
// parameter is a vector of strings that will contain the list of ost
// in returns.  The second parameter is the number of nodes requested.
//
// The most interesting part are the ldap calls and the way to proceed
// to retrieve information from the MDS server using OpenLdap C API.
//
// other interesting implementation can couple LDAP information with
// other info in a DB for example that Time zone of the execution host,
// location, service level aggrement with the requester and the 
// resources provider ...
//*******************************************************************
using namespace std;
namespace itso_broker {

class Host {
	string  hostname;
	long	cpu;
	public:
	Host(string h,int c) : hostname(h), cpu(c) {};
	~Host() { };
	string getHostname() { return hostname; };
	int getCpu() { return cpu; };
};

bool predica(Host* a, Host* b) {
 return (a->getCpu() > b->getCpu());
}


void GetLinuxNodes(vector<string>& res,int n, char* hn_headnode)
{
    LDAP *           ldap_server;
    LDAPMessage *    reply;
    LDAPMessage *    entry;
    char *           attrs[1];
    char *           server   = GRID_INFO_HOST;
    int              port     = atoi(GRID_INFO_PORT);
    char *           base_dn  = GRID_INFO_BASEDN;
    
    /* list of attributes that we want included in the search result */
    attrs[0] = GLOBUS_NULL;

    globus_module_activate(GLOBUS_GRAM_CLIENT_MODULE);
    /* Open connection to LDAP server */
    if ((ldap_server = ldap_open(server, port)) == GLOBUS_NULL)
    {
        ldap_perror(ldap_server, "ldap_open");
        exit(1);
    }

    /* Bind to LDAP server */
    if (ldap_simple_bind_s(ldap_server, "", "") != LDAP_SUCCESS)
    {
        ldap_perror(ldap_server, "ldap_simple_bind_s");
        ldap_unbind(ldap_server);
        exit(1);
    }

    /* do the search to find all the Linux available nodes*/
    //string filter= "(objectClass=MdsComputer)(Mds-Os-name=Linux)";
    string filter= "(&(Mds-Os-name=Linux)(Mds-Host-hn=*))";

    
    if (ldap_search_s(ldap_server, base_dn,
                       LDAP_SCOPE_SUBTREE,
                       const_cast<char*>(filter.c_str()), attrs, 0,
                       &reply) != LDAP_SUCCESS)
    {
        ldap_perror(ldap_server, "ldap_search");
        ldap_unbind(ldap_server);
        exit(1);
    }
    vector<Host*> nodes;

    /* go through the entries returned by the LDAP server. for each
      entry, we must search for the right attribute and then get the
      value associated with it */
    for (entry = ldap_first_entry(ldap_server, reply);
          entry != GLOBUS_NULL;
          entry = ldap_next_entry(ldap_server, entry) )
    {

	
//	cout << endl << ldap_get_dn( ldap_server, entry ) << endl;
	
        BerElement * ber;
        char**  values;
        char *  attr;
        char *  answer = GLOBUS_NULL;
	string 	hostname;
	int 	cpu;
	int 	cpu_nb;
	long 	speed;
	
        for (attr = ldap_first_attribute(ldap_server,entry,&ber);
             attr != NULL;
             attr = ldap_next_attribute(ldap_server,entry,ber) ) 
	{
        	values = ldap_get_values(ldap_server, entry, attr);
            	answer = strdup(values[0]);
            	ldap_value_free(values);
	    	if (strcmp("Mds-Host-hn",attr)==0)
			hostname=answer;
	    	if (strcmp("Mds-Cpu-Free-15minX100",attr)==0)
		    	cpu=atoi(answer);
	    	if (strcmp("Mds-Cpu-Total-count",attr)==0)
		    	cpu_nb=atoi(answer);
	    	if (strcmp("Mds-Cpu-speedMHz",attr)==0)
		    	speed=atoi(answer);
// 	        printf("%s %s\n", attr, answer); 
   	
   	}
	// check if we can really use this node
	if (!globus_gram_client_ping(hostname.c_str())) 
 		nodes.push_back(new Host(hostname,speed*cpu_nb*cpu/100));
	
    };
    sort(nodes.begin(),nodes.end(),predica);
    vector<Host*>::iterator i;
    for(i=nodes.begin();(n>0) && (i!=nodes.end());i++){
	if (strcmp((*i)->getHostname().c_str(), hn_headnode)!=0){
	    res.push_back((*i)->getHostname());
	    n--;
//	    cout << (*i)->getHostname() << " " << (*i)->getCpu() << endl;
	    delete *i;
	}
    }
    for(;i!=nodes.end();++i)
	    delete *i;

    ldap_unbind(ldap_server);
    globus_module_deactivate(GLOBUS_GRAM_CLIENT_MODULE);

} /* get_ldap_attribute */

}
