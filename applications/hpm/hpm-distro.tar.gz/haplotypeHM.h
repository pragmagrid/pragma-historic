// thuat toan Haplotype Pattern Mining

class HPMAlgorithm
{
	int** matrixHaplotype;
	int* vecStatus;
	//du lieu luu luc doc file tham so
	double threshold_x;
	int perTimes;
	int missingAllele;
	int max_lengthPattern;
	int max_numGap;
	int max_sizeGap;
	int totalRow;
	int totalMarker;
	//bo sung them trong thuat toan dung
	int** vec_Allele;
	double num_lb; // can duoi
	//Cau truc du lieu chua ket qua
	int** matrix_HaploSearched;
        int** matrixAllele;
	int countRowMS;
	int* freAllele;
	int totalCase;
	int totalControl;

	//bien dung trong chuong trinh
    int maxRow;
	char fileNameData[100];
	char fileNamePara[100];
	char fileOutPut[100];
//-----------------------------------------------------------------------------
public:
	
	HPMAlgorithm(char* fnD, char* fnP, char* fnOut){
		
			// khoi gan cac gia tri de chay thuat toan HPM
		countRowMS = 0;
		totalCase = 0;
		totalControl = 0;
		strcpy(fileNameData, fnD);
		strcpy(fileNamePara, fnP);		
		strcpy(fileOutPut, fnOut);
	}
	///--------------------------------------------------------------------------
	int runAlgorithm(){
       // doc file du lieu tu file tham so
		int irp = readFileParameter(fileNamePara);
		// doc file du lieu Haplotype + file tham so truyen vao
		int irh = readFileHaplotype();
		if ((irp ==1) && (irh == 1)){
			HaplotypePatternMining();
			return countRowMS;
		}
		return 0;
	}
	//----------------------------------------------------------------------------
	int readFileHaplotype(){

		std::ifstream iFile(fileNameData);
		if (!iFile){
			std::cout << "Khong mo duoc file nay:"<<fileNameData<<"\n";
			return 0;
		}
	
		//std::cout << "Da mo duoc file, Dong: "<<totalRow<<"   Cot:"<<totalMarker<<"\n";
		
		matrixHaplotype = getMemMatrix(totalRow, totalMarker);
		vecStatus = getMemVector(totalRow);
		int countRow = 0;
		//doc bo mot dong dau tien chua char
		char string[100];
		for (int i=0; i<totalMarker+2; i++){
			iFile >> string;
		}

		while ((!iFile.eof()) && (countRow<totalRow)){
			
			int id;
			char status[2];
			iFile >> id;
			iFile >> status;

			if (strcmp(status,"a")==0){
				vecStatus[countRow] = 1;
				totalCase ++;
			}
			else{
				vecStatus[countRow] = 0;
				totalControl ++;
			}
	       
			//doc allele tai markers
			for (int j=0; j<totalMarker; j++)
				iFile >>matrixHaplotype[countRow][j];

       
			countRow++;
		}
		iFile.close();
        return 1;
	}
//-----------------------------------------------------------------------------
	int readFileParameter(char* filename){
			
	// dung doi tuong ifstream de doc file
		std::ifstream iFile(filename);
		if (!iFile){
			std::cout << "Khong mo duoc file nay:"<<filename<<"\n";
			return 0;
		}
		char ten[30];
		//std::cout << "Da mo duoc file"<<"\n";

		while (!iFile.eof()){
		   iFile >> ten;
		  if  (strcmp(ten,"x")==0)
			   iFile >>threshold_x;
		   else
			if (strcmp(ten,"length")==0)
				iFile >>max_lengthPattern;
			else
			if (strcmp(ten,"numgap")==0)
				   iFile >>max_numGap;
			else
			if (strcmp(ten,"sizegap")==0)
				iFile >>max_sizeGap;
			else
			if (strcmp(ten,"per")==0)
				iFile>>perTimes;
			else
			if (strcmp(ten,"total")==0)
				iFile >> totalRow;
		    	else
		   	if (strcmp(ten,"marker")==0)
			     iFile >>totalMarker;
		/*	else if(strcmp(ten,"missing") == 0)
				iFile >>missingAllele; */
		}// while	
		iFile.close();
        return 1;
	}
//-----------------------------------------------------------------------------------
	void createValueMatrix (int** matrixAllele){
		for (int d=0; d<20; d++)
			for (int c=0; c<totalMarker; c++)
				matrixAllele[d][c] = 0;
	}
//-----------------------------------------------------------------------------------
	void getMatrixAllele(int** matrixAllele){
		
		for (int c=0; c<totalMarker; c++){
			int num = 0;
			for (int j=0; j<totalRow; j++)
			if ((matrixHaplotype[j][c] !=0) && (isFound(matrixHaplotype[j][c], matrixAllele, num, c)==0)){
				matrixAllele[num][c] = matrixHaplotype[j][c];
				num++;
			}
		}
	}
 //--------------------------------------------------------------------------------
   int isFound(int value, int** tmp, int num, int cot){
		for (int jj=0;jj<num; jj++)
			if (value == tmp[jj][cot])
				return 1;

		return 0;
	}
//-----------------------------------------------------------------------------
	void HaplotypePatternMining(){

			std::cout <<"Bat dau tim kiem mau Haplotype ............\n";
			std::cout <<"Nguong thong ke x: "<<threshold_x<<"\n";
			std::cout<< "Chieu dai nhat cua mau l: "<<max_lengthPattern<<"\n";
			std::cout <<"So gap lon nhat cua mau g: "<<max_numGap<<"\n";
			std::cout <<"Kich co dai nhat cua mau s: "<<max_sizeGap<<"\n";
			std::cout <<"Total case: "<<totalCase<<"\n";
			std::cout <<"Total control: "<<totalControl<<"\n";

   			maxRow = totalRow*1500;
			int rowAllele = 20;
			std::cout << "Max row: "<<maxRow<<"\n";
			matrix_HaploSearched = getMemMatrix(maxRow, totalMarker);
			matrixAllele = getMemMatrix(rowAllele, totalMarker);
			createValueMatrix(matrixAllele);
			getMatrixAllele(matrixAllele);

			int num_chroTotal = totalControl + totalCase;
			// gia tri can duoi
			num_lb = (totalCase*num_chroTotal*threshold_x)/(totalControl*num_chroTotal+totalCase*threshold_x);
			std::cout <<"can duoi:"<< num_lb<<"\n";
			std::cout << "Tien trinh bat dat xu ly tim mau ....."<<"\n";
			// khoi tao vector mau
			int* pattern_temp = getMemVector(totalMarker); // do co' dau *
            int i;
			for (i=0; i<totalMarker; i++)
					pattern_temp[i]=0; //"*";
					
			//bat dau tim kiem
			for (i=0; i<totalMarker; i++){
                int j=0;
				while ((j<20) && (matrixAllele[j][i]!=0)){
					pattern_temp[i] = matrixAllele[j][i];
					//Kiem tra mau va tat ca khuynh huong mo rong cua no
					depthFirst(pattern_temp, i, i, 0, 0);
					//dat lai pi
					pattern_temp[i] = 0;
					j++;
				}
			}
			//tinh tan so xuat hien cua marker f(mi)
			std::cout <<"Tien trinh tim mau da xong."<<std::endl;
			if (countRowMS>0)
				freAllele = frequencyAllele();
			//xuat vi tri marker co' tan so xuat hien cao nhat
			std::cout << "Luu du lieu."<<std::endl;
			printDataFile(fileOutPut);
			freeMemVector(pattern_temp);
			std::cout <<"Ket thuc chuong trinh HPM."<<std::endl;

	}
//--------------------------------------------------------------------------
	// tim cac pattern theo phuong phap chieu sau
	void depthFirst(int* pattern, int start, int i, int nr_of_gaps, int gap_length){
			
			int pi = pattern[i];
			int matchingCase = countMatchHaplotype(pattern,1);

			if ((i == totalMarker-1) || (i+1-start > max_lengthPattern))
					return;
			if (matchingCase <num_lb) // Xac dinh do tin cay cau mau
					return;
			
			// mo rong mau P o vi tri marker i+1
			//1. Cho Marker i+1 lay cac gia tri co the
           	int ii=0;
			while ((ii<20) && (matrixAllele[ii][i+1]!=0)){
					pattern[i+1] = matrixAllele[ii][i+1];
					depthFirst(pattern, start, i+1, nr_of_gaps, 0);
					ii++;
			}
			//2. Chi dinh mot gap moi bat dau tai marker thu i+1
			if ((pi!=0) && (nr_of_gaps < max_numGap) && (max_sizeGap >= 1)){
					pattern[i+1] = 0;
					depthFirst(pattern, start, i+1, nr_of_gaps+1, 1);					
			}
			//3. Mo rong them gap tren marker i+1
			if ((pi == 0) && (gap_length < max_sizeGap)){
					pattern[i+1] = 0;
					depthFirst(pattern, start, i+1, nr_of_gaps, gap_length+1);					
			}
           //if ((chi_squared(pattern)>=threshold_x) && (pi!=0))
			if ((matchingCase>=num_lb) && (pi!=0))
				addElement(pattern);
			//dat lai P+1 = *
			pattern[i+1] = 0;
			return;			
	}
//---------------------------------------------------------------------------
//Them mot dong vao mang tim duoc
void addElement(int* pattern){
//	int b=0, bb=0;
	int found = 0;
    //kiem tra mau truoc khi add
/*
     for (b=0; b<countRowMS && found ==0; b++){
	int foundi = 1;
	for(bb=0; bb<totalMarker && foundi==1; bb++)
		if (matrix_HaploSearched[b][bb] != pattern[bb])
			foundi = 0;
	if (foundi == 1) found = foundi;
      }
*/
//them mau
      if ((countRowMS < maxRow) && (found == 0)){
		for (int jj=0; jj<totalMarker; jj++)
			  matrix_HaploSearched[countRowMS][jj] = pattern[jj];
        countRowMS ++;
       }
}
//-----------------------------------------------------------------------------
	// Tinh xac suat khi-binh-phuong: do phu hop giua ly thuyen va thuc nghiem
	double chi_squared(int* p){

			int numCaseOfPattern = countMatchHaplotype(p, 1);
			int numNonCaseOfPattern = totalCase - numCaseOfPattern;
			int numControlOfPattern = countMatchHaplotype(p, 0);
			int numNonControlOfPattern = totalControl - numControlOfPattern;
			double TS = (numCaseOfPattern*numNonControlOfPattern - numNonCaseOfPattern * numControlOfPattern)*(numCaseOfPattern*numNonControlOfPattern - numNonCaseOfPattern * numControlOfPattern)*(totalCase + totalControl);
			double MS = (numCaseOfPattern + numNonCaseOfPattern)*(numControlOfPattern+numNonControlOfPattern)*(numCaseOfPattern+numControlOfPattern)*(numNonCaseOfPattern+numNonControlOfPattern);
			
			return TS/MS;
	}
//-----------------------------------------------------------------------------
	// dem so lan mau P phu hop voi tap du lieu HaploData
	//kind = 1: case; kind=0:control;
	int countMatchHaplotype(int* p, int kind){

			int numResult = 0;
			int isCount = 0;
			for (int ii = 0; ii<totalRow; ii++){
				isCount = 1;
				if (vecStatus[ii] == kind){
					for (int jj=0;jj<totalMarker; jj++){
						int hj = matrixHaplotype[ii][jj];
						int pj = p[jj];	
						if ((pj!=0) && (pj!=hj) && (hj!=0))
							isCount = 0;
					}
					if (isCount == 1)
							numResult++;
				}
			}
			return numResult;
	}
//-----------------------------------------------------------------------------
	// do tin cay cay mau haplotype (A)-> (B)disease haplotype Pr(B/A)
	double conf(int* p){

		int matchCase = countMatchHaplotype(p, 1); // dem so lan trung voi haplotype benh
		int matchControl = countMatchHaplotype(p, 0);
		return (matchCase/(matchCase+matchControl));
		
	}
//-----------------------------------------------------------------------------
	// tinh tan so xuat hien cua allele tai marker thu i
	int* frequencyAllele(){
			int* vec_resultFreq = getMemVector(totalMarker);
			int count = 0;
			for (int ii = 0; ii<totalMarker; ii++){ // cot
				count = 0;
				for (int jj = 0; jj<countRowMS; jj++){		//dong
					int pjj = matrix_HaploSearched[jj][ii];
					if (pjj != 0) 
						count++;
					else
					if (pjj == 0){ 
						int isCorrectLeft = 0, isCorrectRight = 0;
						// kiem tra ben trai co' ton tai 1 allele nao khong
						for (int iT=0; iT<ii && (isCorrectLeft==0); iT++)
							if (matrix_HaploSearched[jj][iT] != 0)
								isCorrectLeft = 1;
							// kiem tra ben trai co' ton tai 1 allele nao khong
						if (isCorrectLeft == 1)
							for (int iS=ii+1; iS<totalMarker && (isCorrectRight==0); iS++)
								if (matrix_HaploSearched[jj][iS] != 0)
									isCorrectRight = 1;
						
						if ((isCorrectLeft) && (isCorrectRight))
										count++;
					}
				}
				vec_resultFreq[ii] = count;
			}
			return vec_resultFreq;
	}
//-----------------------------------------------------
	int getTotalMarker(){
    	return totalMarker;
	}
//-----------------------------------------------------
	int getTotalRow(){
    	return totalRow;
	}
//------------------------------------------------------
   int getPerTimes(){
       return perTimes;
   }
//------------------------------------------------------------
   double getThreshold(){
          return threshold_x;
   }
//--------------------------------------------------------
//ghi file ket qua tra ve
	void printDataFile(char* fileO){
			
		std::ofstream fileOut(fileO);
		std::cout <<"Ghi ket qua vao file: "<<fileO<<" tong so tim duoc:"<<countRowMS<<std::endl;
		if (fileOut.is_open())
		{
			fileOut << countRowMS <<"\n";
			for (int i=0; i<countRowMS; i++){
				for (int j=0; j<totalMarker; j++)
					fileOut<<matrix_HaploSearched[i][j]<<"\t";
				fileOut <<"\n";		
			}
			
			fileOut.close();
		}
	}

};//the end of class
