#include "itso_gass_server.h"

namespace itso_gass_server {

globus_mutex_t                mutex;
globus_cond_t                 cond;
bool	                      done;
globus_gass_transfer_listener_t GassServerListener;


void callback_c_function() {
       globus_mutex_lock(&mutex);
       done = true;
       globus_cond_signal(&cond);
}

void StartGASSServer(int port=10000) {
	// Never forget to activate GLOBUS module
	globus_module_activate(GLOBUS_GASS_SERVER_EZ_MODULE);

	// let s define options for our GASS server
	unsigned long server_ez_opts=0UL;

	//Files openfor writing will be written a line at a time
	//so multiple writers can access them safely.
	server_ez_opts |= GLOBUS_GASS_SERVER_EZ_LINE_BUFFER;

	//URLs that have ~ character, will be expanded to the home
	//directory of the user who is running the server
	server_ez_opts |= GLOBUS_GASS_SERVER_EZ_TILDE_EXPAND;

	//URLs that have ~user character, will be expanded to the home
	//directory of the user on the server machine
	server_ez_opts |= GLOBUS_GASS_SERVER_EZ_TILDE_USER_EXPAND;

	//"get" requests will be fullfilled
	server_ez_opts |= GLOBUS_GASS_SERVER_EZ_READ_ENABLE;

	//"put" requests will be fullfilled
	server_ez_opts |= GLOBUS_GASS_SERVER_EZ_WRITE_ENABLE;

	// for put requets on /dev/stdout will be redirected to the standard
	// output stream of the gass server
	server_ez_opts |= GLOBUS_GASS_SERVER_EZ_STDOUT_ENABLE;
	
	// for put requets on /dev/stderr will be redirected to the standard
	// output stream of the gass server
	server_ez_opts |= GLOBUS_GASS_SERVER_EZ_STDERR_ENABLE;

	// "put requests" to the URL https://host/dev/globus_gass_client_shutdown
	// will cause the callback function to be called.  this allows
	// the GASS client to communicate shutdown requests to the server
	server_ez_opts |= GLOBUS_GASS_SERVER_EZ_CLIENT_SHUTDOWN_ENABLE;


	// Secure
	char* scheme="https";
	//unsecure
	//char* scheme="http";
        globus_gass_transfer_listenerattr_t  attr;
        globus_gass_transfer_listenerattr_init(&attr, scheme);
	
        //we want to listen on post 10000
	globus_gass_transfer_listenerattr_set_port(&attr, port);	
	


	//Now, we can start this gass server !	
        globus_gass_transfer_requestattr_t  * reqattr      = GLOBUS_NULL; //purpose unknown
        
        globus_mutex_init(&mutex, GLOBUS_NULL);
        globus_cond_init(&cond, GLOBUS_NULL);
        done = false;

	int err = globus_gass_server_ez_init(&GassServerListener,
                                         &attr,
                                         scheme,
                                         GLOBUS_NULL, //purpose unknown
                                         server_ez_opts,
					 callback_c_function); //or GLOBUS_NULL otherwise
					 //GLOBUS_NULL); //or GLOBUS_NULL otherwise

	if((err != GLOBUS_SUCCESS)) {
	        std::cerr << "Error: initializing GASS (" << err << ")" << std::endl;
	       	exit(1);
	}
	
        char *  gass_server_url=globus_gass_transfer_listener_get_base_url(GassServerListener);
	std::cout << "we are listening on " << gass_server_url << std::endl;
	
};

void StopGASSServer() {
	globus_gass_server_ez_shutdown(GassServerListener);
	globus_module_deactivate(GLOBUS_GASS_SERVER_EZ_MODULE);
};

};
