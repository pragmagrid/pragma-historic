
#ifndef ITSO_BROKER_H
#define ITSO_BROKER_H
/* gris_search.c  */
#include "globus_common.h"
/* LDAP stuff */
#include "lber.h"
#include "ldap.h"
#include <string>
#include <vector>
#include <list>
#include <algorithm>


/* note this should be the GIIS server, but it could be the 
   GRIS server if you are only talking to a local machine 
   remember the port numbers are different */ 

#define GRID_INFO_HOST "172.25.97.34"
#define GRID_INFO_PORT "2135"
#define GRID_INFO_BASEDN "mds-vo-name=IOIT-HCM, o=Grid"
using namespace std;
namespace itso_broker {


void GetLinuxNodes(vector<string>& res,int n, char* hn_headnode);
}
#endif
