#ifndef ITSO_ITSO_GLOBUS_FTP_CLIENT_H
#define ITSO_ITSO_GLOBUS_FTP_CLIENT_H
#include <cstdio>
#include <iostream>
#include "globus_ftp_client.h"
#include "itso_cb.h"
using namespace std;
#define _(a) r=a;\
        if (r!=GLOBUS_SUCCESS) {\
		cerr << globus_object_printable_to_string(globus_error_get(r));\
		exit(1);\
        }


#define MAX_BUFFER_SIZE 2048
#define SUCCESS 0

//*************************************************************************


class ITSO_GLOBUS_FTP_CLIENT : public ITSO_CB {
	FILE*			fd;
    	globus_byte_t           buffer[MAX_BUFFER_SIZE];
	globus_ftp_client_handle_t              handle;
	public:
    	ITSO_GLOBUS_FTP_CLIENT(char*,char*);
	~ITSO_GLOBUS_FTP_CLIENT();
	void StartTransfer();
	void Transfer( globus_byte_t*, globus_size_t&,globus_off_t&);
};
#endif
