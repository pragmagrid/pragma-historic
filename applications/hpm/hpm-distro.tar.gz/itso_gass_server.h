#ifndef ITSO_GASS_SERVER_H
#define ITSO_GASS_SERVER_H

#include <unistd.h>
#include "globus_common.h"
#include "globus_gass_server_ez.h"
#include <iostream>
using namespace std;
namespace itso_gass_server {

void StartGASSServer(int);

void StopGASSServer(); 

};

#endif
