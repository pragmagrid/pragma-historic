#ifndef ITSO_CB_H
#define ITSO_CB_H
#include <cstdio>
#include <iostream>
#include <globus_common.h>

class ITSO_CB {
 	globus_mutex_t mutex;
	globus_cond_t cond;
	globus_bool_t done;
     public:
	ITSO_CB() {
 	   	globus_mutex_init(&mutex, GLOBUS_NULL);
    		globus_cond_init(&cond, GLOBUS_NULL);
		done = GLOBUS_FALSE ;
	};
	~ITSO_CB() {
              globus_mutex_destroy(&mutex);
              globus_cond_destroy(&cond);
	};	
	globus_bool_t IsDone();
        void setDone(); 
        void Continue();
	virtual void Wait(); 
	void Lock();
	void UnLock(); 
};
#endif
