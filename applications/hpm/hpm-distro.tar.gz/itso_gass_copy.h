#ifndef ITSO_GASS_COPY_H
#define ITSO_GASS_COPY_H
#include "globus_common.h"
#include "globus_gass_copy.h"
#include "itso_cb.h"
#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>

using namespace std;
class GLOBUS_FILE {
	globus_io_handle_t *	io_handle;
	int			file_fd;
      public:
	GLOBUS_FILE();
	GLOBUS_FILE(char* );
	~GLOBUS_FILE();
	globus_io_handle_t * GLOBUS_FILE::get_globus_io_handle();
};

class GLOBUS_URL {
	globus_url_t 			url;
	globus_gass_copy_url_mode_t 	url_mode;
	char* 				URL;
	public:
		GLOBUS_URL();
		~GLOBUS_URL(); 
		bool setURL(char* destURL); 
		bool setURL(std::string destURL); 
		globus_gass_copy_url_mode_t getMode(); 
		char* getScheme(); 
		char* getURL();
};

class ITSO_GASS_TRANSFER_EXCEPTION { };

class ITSO_GASS_TRANSFER : public ITSO_CB {
	globus_gass_copy_handle_t          	gass_copy_handle;
	globus_gass_copy_handleattr_t      	gass_copy_handleattr;
	globus_gass_transfer_requestattr_t*	dest_gass_attr;
	globus_gass_copy_attr_t 		dest_gass_copy_attr;
	globus_gass_transfer_requestattr_t*	source_gass_attr;
	globus_gass_copy_attr_t 		source_gass_copy_attr;
	globus_gass_copy_url_mode_t 		source_url_mode;
	globus_gass_copy_url_mode_t 		dest_url_mode;
	globus_ftp_client_operationattr_t*	dest_ftp_attr;
	globus_ftp_client_operationattr_t*	source_ftp_attr;
	void setSource(GLOBUS_URL& ); 
	void setDestination(GLOBUS_URL& ); 
	public:
	ITSO_GASS_TRANSFER(); 
	~ITSO_GASS_TRANSFER(); 
	void Transfer(GLOBUS_FILE& , GLOBUS_URL& ); 
	void Transfer(GLOBUS_URL&,GLOBUS_FILE&); 
	void Transfer(GLOBUS_URL& ,GLOBUS_URL& );
};

#endif
